package com.example.calculator;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b0, badd, bsub,bmul, bdiv, bsubmit,click, bclear, bdot;
    Boolean Add = false;
    Boolean sub = false;
    Boolean div = false;
    Boolean mul = false;
    Boolean dot = true;

    TextView ed1, ed2;
    float val1, val2;


    public void btnClick(View view){


    }


    @Nullable
    @Override
    public View getCurrentFocus() {
        return super.getCurrentFocus();
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        b0 = findViewById(R.id.b0);
        bdot = findViewById(R.id.bdot);
        badd = findViewById(R.id.badd);
        bsub = findViewById(R.id.bsub);
        bdiv = findViewById(R.id.bdiv);
        bmul = findViewById(R.id.bmul);
        bsubmit = findViewById(R.id.bsubmit);
        bclear = findViewById(R.id.bclear);
        ed1 = findViewById(R.id.number);
        ed2 = findViewById(R.id.number2);


        b1.setOnClickListener(v -> ed1.setText(ed1.getText() + "1"));

        b2.setOnClickListener(v -> ed1.setText(ed1.getText() + "2"));

        b3.setOnClickListener(v -> ed1.setText(ed1.getText() + "3"));

        b4.setOnClickListener(v -> ed1.setText(ed1.getText() + "4"));

        b5.setOnClickListener(v -> ed1.setText(ed1.getText() + "5"));

        b6.setOnClickListener(v -> ed1.setText(ed1.getText() + "6"));

        b7.setOnClickListener(v -> ed1.setText(ed1.getText() + "7"));

        b8.setOnClickListener(v -> ed1.setText(ed1.getText() + "8"));

        b9.setOnClickListener(v -> ed1.setText(ed1.getText() + "9"));

        b0.setOnClickListener(v -> ed1.setText(ed1.getText() + "0"));

        bdot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(dot) {
                    ed1.setText(ed1.getText() + ".");
                    dot = false;
                }
                else {
                    ed2.setText("Invalid Input");
                }
            }
        });


        bdiv.setOnClickListener(v -> {
            if(ed1.getText()  == "" )
                ed1.setText("");
            else{
                val1 = Float.parseFloat(ed1.getText() + "");
                div = true;
                dot = true;
                ed1.setText(null);
                ed2.setText(val1 + "");
            }
        });


        bmul.setOnClickListener(v -> {
            if(ed1.getText()  == "" )
                ed1.setText("");
            else{
                val1 = Float.parseFloat(ed1.getText() + "");
                mul = true;
                dot = true;
                ed1.setText(null);
                ed2.setText(val1 + "");
            }
        });

        badd.setOnClickListener(v -> {
            if(ed1.getText()  == "" )
                ed1.setText("");
            else{
                val1 = Float.parseFloat(ed1.getText() + "");
                Add = true;
                dot = true;
                ed1.setText(null);
                ed2.setText(val1 + "");
            }
        });


        bsub.setOnClickListener(v -> {
            if(ed1.getText()  == "" )
                ed1.setText("");
            else{
                val1 = Float.parseFloat(ed1.getText() + "");
                sub = true;
                dot = true;
                ed1.setText(null);
                ed2.setText(val1 + "");
            }
        });


        bsubmit.setOnClickListener(v -> {

            if(ed1.getText()  == "" )
                ed1.setText("");
            else {
                val2 = Float.parseFloat(ed1.getText() + "");
                if (Add) {
                    ed1.setText((val1 + val2) + "");
                    Add = false;
                    ed2.setText("");
                }

                if (sub) {
                    ed1.setText((val1 - val2) + "");
                    sub = false;
                    ed2.setText("");
                }

                if (div) {
                    ed1.setText((val1 / val2) + "");
                    div = false;
                    ed2.setText("");
                }

                if(mul) {
                    ed1.setText((val1 * val2) + "");
                    mul = false;
                    ed2.setText("");
                }
            }

            });


        bclear.setOnClickListener(v -> ed1.setText(""));


    }
}